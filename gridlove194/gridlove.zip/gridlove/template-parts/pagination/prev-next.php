<nav class="gridlove-pagination">
	
	<div class="gridlove-prev">
		<?php previous_posts_link( __gridlove( 'newer_entries' ) ); ?>
	</div>

	<div class="gridlove-next">
		<?php next_posts_link( __gridlove( 'older_entries' ) ); ?>
	</div>

</nav>