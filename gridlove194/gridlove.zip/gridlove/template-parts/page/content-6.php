<div class="box-inner-p-bigger box-single">
    <?php get_template_part('template-parts/page/entry-content'); ?>
    <?php get_template_part('template-parts/page/author'); ?>
</div>