<div class="box-inner-p-bigger box-single gridlove-to-center">
	<?php get_template_part('template-parts/page/entry-header'); ?>
    <?php get_template_part('template-parts/page/entry-content'); ?>
</div>