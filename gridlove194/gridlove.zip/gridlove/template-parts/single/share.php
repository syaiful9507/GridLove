<?php if( gridlove_get_option('single_share') && function_exists('meks_ess_share') ): ?>

		<div class="gridlove-share-wrapper">
			<div class="gridlove-share gridlove-box gridlove-sticky-share">

				<?php meks_ess_share(); ?>

			</div>
		</div>
	
<?php endif; ?>